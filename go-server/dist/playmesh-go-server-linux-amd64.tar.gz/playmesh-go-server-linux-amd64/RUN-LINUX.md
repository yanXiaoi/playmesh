# Linux deployment

Target: linux/amd64

1. Copy the environment template: `cp .env.example .env`
2. Configure `.env`, especially the user/admin JWT secrets and admin credentials.
3. Make the binary executable: `chmod +x playmesh-go-server`
4. Start it from this directory: `./playmesh-go-server`

The server reads `server.json` and `.env` from its working directory.
The default configuration requires ClamAV and the `clamscan` command. See README.md.
The runtime user needs read/write permissions for the pre-created `data/` directory.